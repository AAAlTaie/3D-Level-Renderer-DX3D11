var class_g_w_1_1_s_y_s_t_e_m_1_1_g_window =
[
    [ "EVENT_DATA", "struct_g_w_1_1_s_y_s_t_e_m_1_1_g_window_1_1_e_v_e_n_t___d_a_t_a.html", "struct_g_w_1_1_s_y_s_t_e_m_1_1_g_window_1_1_e_v_e_n_t___d_a_t_a" ],
    [ "Events", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139", [
      [ "MINIMIZE", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139a704bfa6c1ed5e479c8cfb5bdfc8cccda", null ],
      [ "MAXIMIZE", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139a7af98b3d657f545ebf5476f68cb5ce6f", null ],
      [ "RESIZE", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139a1acac8984c2139895dee3e8aa928de57", null ],
      [ "MOVE", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139af7f93635f8e193a924ae4a691bb66b8f", null ],
      [ "DISPLAY_CLOSED", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139a00b8cc9675bbfab99e5719fc3454fbdc", null ],
      [ "EVENTS_PROCESSED", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139a349e16b498324e045792e604e21cd052", null ],
      [ "DESTROY", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a1c15f56e0f77fd4aaf6261b990f66139ac39aa6dbe619bb8ef8187b00b686df6a", null ]
    ] ],
    [ "Create", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a2d7548a2f9671c801293a64b9ecca207", null ],
    [ "ProcessWindowEvents", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a6c7db60db04436ac21cba3147f287e84", null ],
    [ "ReconfigureWindow", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a71c015d7ac4d71f81e73367fcec464ea", null ],
    [ "SetWindowName", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a7363e8eec8aebed1634d97706b4f391f", null ],
    [ "SetIcon", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#ad350ab949dbab74780c47c54b8906be3", null ],
    [ "MoveWindow", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a9fc043b893f26c35e6ba965adcc17edb", null ],
    [ "ResizeWindow", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a92633707248f32e4c166f27f03690d6d", null ],
    [ "Maximize", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a06b5f092e742baca82a0bfc2cbaef153", null ],
    [ "Minimize", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a2cced61a323dac10535904c3899563d8", null ],
    [ "ChangeWindowStyle", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a0a0bdaae275c5ee616972e8431238d00", null ],
    [ "GetWidth", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a616497a3faa787d3b22f0146db7a1645", null ],
    [ "GetHeight", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a216573d26f053c9b8e8cfb71f8fb16f9", null ],
    [ "GetClientWidth", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#acc9e7305d5f1e2f793184718023d0f25", null ],
    [ "GetClientHeight", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a036e77988a33af4e85f6f904879d2d1f", null ],
    [ "GetX", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a81a25fe9b7507c21c580477d31fe7eee", null ],
    [ "GetY", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a326d51c22d4fee456ef9377d85a3786c", null ],
    [ "GetClientTopLeft", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#ae784e20597fa93105a311f832166062e", null ],
    [ "GetWindowHandle", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a64ea90e2bc439c7af74dbf536bc3bd59", null ],
    [ "IsFullscreen", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#af8bb7372c94d3ef5e42983265613c286", null ],
    [ "IsFocus", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html#a7d9ed8b19dc4c5f7e9dd93701ce943a3", null ]
];