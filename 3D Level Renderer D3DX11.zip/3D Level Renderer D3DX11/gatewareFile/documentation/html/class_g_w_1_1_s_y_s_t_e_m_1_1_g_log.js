var class_g_w_1_1_s_y_s_t_e_m_1_1_g_log =
[
    [ "Create", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#a2bec61a449453d5e6d3c0724638f4ab1", null ],
    [ "Create", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#a40a288e9cd3084060f316fbecba80838", null ],
    [ "Log", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#a9e21e702d012065fe799b4c49f7ac670", null ],
    [ "LogCategorized", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#ac5f0a8ff17e62879bc99e0746aead561", null ],
    [ "EnableVerboseLogging", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#adea469091bba33b419f7e88a9c2c3049", null ],
    [ "EnableConsoleLogging", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#a1eb651aa3d5b6b8baac389be284a569d", null ],
    [ "Flush", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html#a07147c15ecb17caa1c83974b3c54f7d4", null ]
];