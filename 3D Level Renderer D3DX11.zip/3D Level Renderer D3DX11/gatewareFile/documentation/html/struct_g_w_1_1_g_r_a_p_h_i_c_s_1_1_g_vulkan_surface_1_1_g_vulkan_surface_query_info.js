var struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info =
[
    [ "initializationMask", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a6f6ba2e41a92e2d22b2c541f93d9670b", null ],
    [ "instanceLayerCount", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#ae2ea188593d3bd629743bbad175f7ab7", null ],
    [ "instanceLayers", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a7210843b02a041eb5c9698afb50ab789", null ],
    [ "instanceLayerProperties", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a478f2b185e727574e28d177d9847e4d6", null ],
    [ "instanceExtensionCount", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#aa799bd66503c2714ee0ad01148703ec8", null ],
    [ "instanceExtensions", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a25a92cf413c1d078678422ceedad35d9", null ],
    [ "instanceExtensionProperties", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a462c382e7cc5c29f9c5cf09ad41ad04c", null ],
    [ "deviceExtensionCount", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a0dedba2314e31a8f7641f29b757fcaf6", null ],
    [ "deviceExtensions", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a3f851bf3c1346029aac4d73e9b6cd83a", null ],
    [ "deviceExtensionProperties", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a96047d29f4e20102bdd058690c637c4c", null ],
    [ "physicalDeviceFeatures", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a74feb81e217013d2ba2a90de59c9f426", null ]
];