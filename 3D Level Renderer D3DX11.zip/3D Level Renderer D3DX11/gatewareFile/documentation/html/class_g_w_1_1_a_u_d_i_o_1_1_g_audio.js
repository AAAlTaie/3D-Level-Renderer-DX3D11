var class_g_w_1_1_a_u_d_i_o_1_1_g_audio =
[
    [ "EVENT_DATA", "struct_g_w_1_1_a_u_d_i_o_1_1_g_audio_1_1_e_v_e_n_t___d_a_t_a.html", "struct_g_w_1_1_a_u_d_i_o_1_1_g_audio_1_1_e_v_e_n_t___d_a_t_a" ],
    [ "Events", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594", [
      [ "DESTROY", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594ac39aa6dbe619bb8ef8187b00b686df6a", null ],
      [ "PLAY_SOUNDS", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a5369977bc8bce25995d0c4ad6a804a19", null ],
      [ "PAUSE_SOUNDS", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a51270e7a75f635516aaea5e80e379b05", null ],
      [ "RESUME_SOUNDS", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a2d509f52b7d4b8cb914f280b65d3b9c1", null ],
      [ "STOP_SOUNDS", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a2312ce1b2f3f9054100a39b9cc5e8b19", null ],
      [ "PLAY_MUSIC", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a326bc2e703adc09914931dd97f974c0a", null ],
      [ "PAUSE_MUSIC", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a617087d660fd8a08964786a683afb997", null ],
      [ "RESUME_MUSIC", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594ae01b0b376748f1c27f381d059de1b953", null ],
      [ "STOP_MUSIC", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594aebaf377fcb1a84bf327953e3e6bd1fd8", null ],
      [ "MASTER_VOLUME_CHANGED", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594ae8137d8aeb3c070c08e323e5f0f3d4ff", null ],
      [ "SOUNDS_VOLUME_CHANGED", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a88e02471ae454e1336077a3d3002a477", null ],
      [ "MUSIC_VOLUME_CHANGED", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594ae190113d662290cec9f4fa5b0252d9ae", null ],
      [ "SOUND_CHANNEL_VOLUMES_CHANGED", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a0f0ef10572d957cc38308b75c55f5f2c", null ],
      [ "MUSIC_CHANNEL_VOLUMES_CHANGED", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4d73263ecce0031b22d3d705fd020594a86c7418ea44b8c0b982ef256bac856cf", null ]
    ] ],
    [ "Create", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#ab701f751e957b794015670f0abd2f061", null ],
    [ "SetMasterVolume", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a34fb1be1551ce0e73bdb439e8d7ffcfa", null ],
    [ "SetGlobalSoundVolume", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a6ef79689db1bd226f8cecc8650ac7b43", null ],
    [ "SetGlobalMusicVolume", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a0c9f9d63e8746cd0ad05d5ff7a39aeb8", null ],
    [ "SetSoundsChannelVolumes", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a8970773198f16526f092b7f00f514bee", null ],
    [ "SetMusicChannelVolumes", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a4c5ecedfed30e96aa190b91691552be1", null ],
    [ "PlaySounds", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#aad39146789f971efd672ec9fc3325242", null ],
    [ "PauseSounds", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a2408c18540848bc95597480d3df92a71", null ],
    [ "ResumeSounds", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#accfa6584931c57e15e3f7f109bcdec3b", null ],
    [ "StopSounds", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#af0d5d8e2516c41e8135ff64d35ee049e", null ],
    [ "PlayMusic", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a239416e538b9b97636f2ef1318a7b3ad", null ],
    [ "PauseMusic", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#a1cabf995a63003aa82a673f3089c928a", null ],
    [ "ResumeMusic", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#af51b6d7c57c43a00b58ace22606f1b7c", null ],
    [ "StopMusic", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html#aa3990132789dc5e1ca544a935df1d0c1", null ]
];