var searchData=
[
  ['universal_5fwindow_5fhandle_0',['UNIVERSAL_WINDOW_HANDLE',['../struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html',1,'GW::SYSTEM']]]
];
