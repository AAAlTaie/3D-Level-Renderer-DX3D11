var modules =
[
    [ "AudioOptions", "group___audio_options.html", "group___audio_options" ],
    [ "GReturnValues", "group___g_return_values.html", "group___g_return_values" ],
    [ "Operators", "group___operators.html", "group___operators" ],
    [ "GraphicsOptions", "group___graphics_options.html", "group___graphics_options" ],
    [ "GInputCodes", "group___g_input_codes.html", null ],
    [ "GControllerCodes", "group___g_controller_codes.html", null ],
    [ "MathStructures", "group___math_structures.html", "group___math_structures" ],
    [ "SystemDefines", "group___system_defines.html", "group___system_defines" ]
];