var struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a =
[
    [ "data", "struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#aa3def74bc6bf80ecddc5529ffcd48ffc", null ],
    [ "x", "struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#ad1dcc3c890ed96608e893252b80f704d", null ],
    [ "y", "struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#a40c938fb94c8a0908bfac85f62f71fc9", null ],
    [ "screenX", "struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#af3d4504c9b36f06a962b0aed6fa4d982", null ],
    [ "screenY", "struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#adfbabf0902d029c5571115771fb379a6", null ],
    [ "keyMask", "struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#aba540ab043d90612e6eb326221a56bfa", null ]
];