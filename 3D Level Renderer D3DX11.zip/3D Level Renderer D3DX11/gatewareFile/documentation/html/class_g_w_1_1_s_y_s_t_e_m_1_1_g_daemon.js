var class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon =
[
    [ "EVENT_DATA", "struct_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon_1_1_e_v_e_n_t___d_a_t_a.html", "struct_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon_1_1_e_v_e_n_t___d_a_t_a" ],
    [ "Events", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a9181a6ad11f965c4fc71662dc51ba785", [
      [ "OPERATION_COMPLETED", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a9181a6ad11f965c4fc71662dc51ba785a534f3ca6c24f045bbee1f07f511fe26e", null ],
      [ "OPERATIONS_PAUSED", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a9181a6ad11f965c4fc71662dc51ba785a06cb0146cbe84b88248bd766d16af2b4", null ],
      [ "OPERATIONS_RESUMING", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a9181a6ad11f965c4fc71662dc51ba785afd35988fa8ace3e1d4c45b2f6e157235", null ]
    ] ],
    [ "Create", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a8dfb943eaf07ca8f36e57476a82dfc1d", null ],
    [ "Create", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a93136d7b5e2724c533c5189031449d91", null ],
    [ "Create", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#aa7040c60c9beb65a6f6b2dcf3d1eedc5", null ],
    [ "Pause", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a29fb1e662898e32c3f39f2874a8dafcd", null ],
    [ "Resume", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#aed153845defdabbefe4f8dd62d216737", null ],
    [ "Counter", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html#a9fa24f1f7ae574fa5b6260e1c8aee3f0", null ]
];