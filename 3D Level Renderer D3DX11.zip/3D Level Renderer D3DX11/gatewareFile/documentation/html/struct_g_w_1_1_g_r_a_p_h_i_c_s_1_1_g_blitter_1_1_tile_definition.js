var struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition =
[
    [ "x", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#aad10cee4c78ee9bcf33aa3d58182561a", null ],
    [ "y", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#a2deed3f43c2c92848d4418b1db54ef4b", null ],
    [ "w", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#ab2aa24598777a773c21db054447377c7", null ],
    [ "h", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#a5dc91ff0e27e4c7e0af2ea8dfecd4f8c", null ],
    [ "mask_color", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#aa6ee7a462ac887e6c6d72909c47ba598", null ],
    [ "mask_layer", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#a2965758110dabb6b79ef01b4e32ba1e0", null ],
    [ "mask_stencil", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#a46961c12696784aad62b90cbcda817a3", null ]
];