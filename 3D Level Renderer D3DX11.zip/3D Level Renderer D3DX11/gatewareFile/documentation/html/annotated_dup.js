var annotated_dup =
[
    [ "GW", "namespace_g_w.html", [
      [ "AUDIO", "namespace_g_w_1_1_a_u_d_i_o.html", [
        [ "GAudio", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio.html", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio" ],
        [ "GAudio3D", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio3_d.html", "class_g_w_1_1_a_u_d_i_o_1_1_g_audio3_d" ],
        [ "GMusic", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html", "class_g_w_1_1_a_u_d_i_o_1_1_g_music" ],
        [ "GMusic3D", "class_g_w_1_1_a_u_d_i_o_1_1_g_music3_d.html", "class_g_w_1_1_a_u_d_i_o_1_1_g_music3_d" ],
        [ "GSound", "class_g_w_1_1_a_u_d_i_o_1_1_g_sound.html", "class_g_w_1_1_a_u_d_i_o_1_1_g_sound" ],
        [ "GSound3D", "class_g_w_1_1_a_u_d_i_o_1_1_g_sound3_d.html", "class_g_w_1_1_a_u_d_i_o_1_1_g_sound3_d" ]
      ] ],
      [ "CORE", "namespace_g_w_1_1_c_o_r_e.html", [
        [ "GEventCache", "class_g_w_1_1_c_o_r_e_1_1_g_event_cache.html", "class_g_w_1_1_c_o_r_e_1_1_g_event_cache" ],
        [ "GEventGenerator", "class_g_w_1_1_c_o_r_e_1_1_g_event_generator.html", "class_g_w_1_1_c_o_r_e_1_1_g_event_generator" ],
        [ "GEventQueue", "class_g_w_1_1_c_o_r_e_1_1_g_event_queue.html", "class_g_w_1_1_c_o_r_e_1_1_g_event_queue" ],
        [ "GEventReceiver", "class_g_w_1_1_c_o_r_e_1_1_g_event_receiver.html", "class_g_w_1_1_c_o_r_e_1_1_g_event_receiver" ],
        [ "GEventResponder", "class_g_w_1_1_c_o_r_e_1_1_g_event_responder.html", "class_g_w_1_1_c_o_r_e_1_1_g_event_responder" ],
        [ "GInterface", "class_g_w_1_1_c_o_r_e_1_1_g_interface.html", "class_g_w_1_1_c_o_r_e_1_1_g_interface" ],
        [ "GLogic", "class_g_w_1_1_c_o_r_e_1_1_g_logic.html", "class_g_w_1_1_c_o_r_e_1_1_g_logic" ],
        [ "GThreadShared", "class_g_w_1_1_c_o_r_e_1_1_g_thread_shared.html", "class_g_w_1_1_c_o_r_e_1_1_g_thread_shared" ]
      ] ],
      [ "GRAPHICS", "namespace_g_w_1_1_g_r_a_p_h_i_c_s.html", [
        [ "GBlitter", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter" ],
        [ "GDirectX11Surface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x11_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x11_surface" ],
        [ "GDirectX12Surface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x12_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x12_surface" ],
        [ "GOpenGLSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface" ],
        [ "GRasterSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_raster_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_raster_surface" ],
        [ "GVulkanSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface" ]
      ] ],
      [ "INPUT", "namespace_g_w_1_1_i_n_p_u_t.html", [
        [ "GBufferedInput", "class_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input.html", "class_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input" ],
        [ "GController", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller" ],
        [ "GInput", "class_g_w_1_1_i_n_p_u_t_1_1_g_input.html", "class_g_w_1_1_i_n_p_u_t_1_1_g_input" ]
      ] ],
      [ "MATH", "namespace_g_w_1_1_m_a_t_h.html", [
        [ "GAABBCED", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html", null ],
        [ "GAABBCEF", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html", null ],
        [ "GAABBMMD", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html", null ],
        [ "GAABBMMF", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html", null ],
        [ "GCAPSULED", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html", null ],
        [ "GCAPSULEF", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html", null ],
        [ "GCollision", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html", "class_g_w_1_1_m_a_t_h_1_1_g_collision" ],
        [ "GLINED", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html", null ],
        [ "GLINEF", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html", null ],
        [ "GMatrix", "class_g_w_1_1_m_a_t_h_1_1_g_matrix.html", "class_g_w_1_1_m_a_t_h_1_1_g_matrix" ],
        [ "GMATRIXD", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html", null ],
        [ "GMATRIXF", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html", null ],
        [ "GOBBD", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html", null ],
        [ "GOBBF", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html", null ],
        [ "GPLANED", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html", null ],
        [ "GPLANEF", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html", null ],
        [ "GQuaternion", "class_g_w_1_1_m_a_t_h_1_1_g_quaternion.html", "class_g_w_1_1_m_a_t_h_1_1_g_quaternion" ],
        [ "GQUATERNIOND", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html", null ],
        [ "GQUATERNIONF", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html", null ],
        [ "GRAYD", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html", null ],
        [ "GRAYF", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html", null ],
        [ "GSPHERED", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html", null ],
        [ "GSPHEREF", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html", null ],
        [ "GTRIANGLED", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html", null ],
        [ "GTRIANGLEF", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html", null ],
        [ "GVector", "class_g_w_1_1_m_a_t_h_1_1_g_vector.html", "class_g_w_1_1_m_a_t_h_1_1_g_vector" ],
        [ "GVECTORD", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html", null ],
        [ "GVECTORF", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html", null ]
      ] ],
      [ "MATH2D", "namespace_g_w_1_1_m_a_t_h2_d.html", [
        [ "GBARYCENTRICD", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_d.html", null ],
        [ "GBARYCENTRICF", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_f.html", null ],
        [ "GCAPSULE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_d.html", null ],
        [ "GCAPSULE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_f.html", null ],
        [ "GCIRCLE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_d.html", null ],
        [ "GCIRCLE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_f.html", null ],
        [ "GCollision2D", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d" ],
        [ "GLINE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_d.html", null ],
        [ "GLINE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_f.html", null ],
        [ "GMATRIX2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_d.html", null ],
        [ "GMatrix2D", "class_g_w_1_1_m_a_t_h2_d_1_1_g_matrix2_d.html", "class_g_w_1_1_m_a_t_h2_d_1_1_g_matrix2_d" ],
        [ "GMATRIX2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_f.html", null ],
        [ "GMATRIX3D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_d.html", null ],
        [ "GMATRIX3F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_f.html", null ],
        [ "GRAY2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_d.html", null ],
        [ "GRAY2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_f.html", null ],
        [ "GRECTANGLE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_d.html", null ],
        [ "GRECTANGLE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_f.html", null ],
        [ "GVECTOR2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_d.html", null ],
        [ "GVector2D", "class_g_w_1_1_m_a_t_h2_d_1_1_g_vector2_d.html", "class_g_w_1_1_m_a_t_h2_d_1_1_g_vector2_d" ],
        [ "GVECTOR2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_f.html", null ],
        [ "GVECTOR3D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html", null ],
        [ "GVECTOR3F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html", null ]
      ] ],
      [ "SYSTEM", "namespace_g_w_1_1_s_y_s_t_e_m.html", [
        [ "GConcurrent", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_concurrent.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_concurrent" ],
        [ "GDaemon", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon" ],
        [ "GFile", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_file.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_file" ],
        [ "GLog", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log" ],
        [ "GWindow", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window" ],
        [ "UNIVERSAL_WINDOW_HANDLE", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e" ]
      ] ],
      [ "GEvent", "struct_g_w_1_1_g_event.html", "struct_g_w_1_1_g_event" ]
    ] ]
];